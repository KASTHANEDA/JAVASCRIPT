/**
Ejercicio 1
Crear un documento con el nombre ej1.js
Declarar una variable nombre
Declarar una variable apellido
Declarar una variable edad
Declarar una variable fecha de nacimiento utilizando camel case
Declarar una variable direccion
 * 
 */

var nombre, apellido, edad, fechaNac, direccion;
