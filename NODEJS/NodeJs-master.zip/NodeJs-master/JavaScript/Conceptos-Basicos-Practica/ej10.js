/**
 * Ejercicio 10
Crear un documento con el nombre ej10.js
Declarar una variable saludo
Asignar el valor: ECMAScript rocks!! a la variable saludo, 
con el tipo de dato string

Mostrar el contenido de la variable saludo utilizando console.log()
 */

let saludo = 'ECMAScript rocks!!';
console.log(saludo);