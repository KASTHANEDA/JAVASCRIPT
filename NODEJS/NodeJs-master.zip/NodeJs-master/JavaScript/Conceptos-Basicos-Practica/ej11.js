/**
 * Ejercicio 11
Crear un documento con el nombre ej11.js
Mostrar el siguiente mensaje:
 
Me gusta mucho ECMAScript, en consola sin utilizar una variable
 */

console.log('Me gusta mucho ECMAScript');