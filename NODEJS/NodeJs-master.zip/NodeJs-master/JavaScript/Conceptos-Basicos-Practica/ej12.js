/**
 * Ejercicio 12
Crear un documento con el nombre ej12.js

Declarar una variable nombre con tu nombre. Declarar una variable saludo con 
el siguiente mensaje: 

Bienvenido/a. Mostrar en consola el mensaje de bienvenida 
utilizando console.log() y concatenando las variables nombre y 
saludo para que muestre un mensaje similar a: Bienvenido/a Marta
 */

let nombre='Marta', saludo='Bienvenido/a';

console.log(`${saludo} ${nombre}`);