/**
 Ejercicio 13
Crear un documento con el nombre ej13.js
Declarar una variable nombre con tu nombre
Declarar una variable saludo con el siguiente mensaje: 
Bienvenido/a. Mostrar en consola el siguiente mensaje:
Bienvenido/a Marta al curso de ECMAScript!!

Utilizar console.log(), las variable nombre, saludo y un valor string para el resto
del mensaje que no está en una variable 
 
 */

let nombre='Marta', saludo='Bienvenido/a';

console.log(`${saludo} ${nombre} al curso de ECMAScript!!`);