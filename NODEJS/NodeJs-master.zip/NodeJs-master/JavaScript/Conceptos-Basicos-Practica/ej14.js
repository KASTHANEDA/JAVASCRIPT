/**
 * Ejercicio 14
Crear un documento con el nombre ej14.js
Declarar una variable nombre con tu nombre
Declarar una variable saludo con el siguiente valro: Bienvenido/a
Declarar una variable finDeSaludo con el siguiente valor: al curso de ECMAScript!!
Mostrar en consola el siguiente mensaje: Bienvenido/a Marta al curso de ECMAScript!! 
utilizando console.log() y concatenando las 3 variables
 */

let nombre = 'Marta', saludo = 'Bienvenido/a', finDeSaludo = 'al curso de ECMAScript!!';

console.log(`${saludo} ${nombre} ${finDeSaludo}`);