/**
 * Ejercicio 15
Crear un documento con el nombre ej15.js
Declarar una variable alumno
Asignar a la variable alumno el nombre del mejor alumno del curso
Mostrar en consola el siguiente mensaje: 
El mejor alumno es: y el contenido de la variable alumno
Utilizar interpolación de textos
 */

let alumno = 'Pepe';
console.log(`El mejor alumno es: ${alumno}`);