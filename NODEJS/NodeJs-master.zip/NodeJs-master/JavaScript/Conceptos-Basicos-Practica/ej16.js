/**
* Ejercicio 16
Crear un documento con el nombre ej16.js
Copiar el contenido del ejercicio anterior (ej15) y pegarlo en el nuevo archivo
Modificar el código para mostrar el mismo mensaje en consola pero concatenando
los textos en lugar de utilizar interpolación de texto
*/

let alumno = 'Pepe';
console.log('El mejor alumno es:'+ alumno);