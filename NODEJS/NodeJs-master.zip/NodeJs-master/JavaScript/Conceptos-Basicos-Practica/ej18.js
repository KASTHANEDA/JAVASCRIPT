/**
 * Ejercicio 18
Crear un documento con el nombre ej18.js
Declarar una variable local con el valor: Gianu's
Declarar una variable mensaje con el valor: es el "mejor" local
Mostrar en consola el mensaje: Gianu's es el "mejor" local
 */

let local = "Gianu's", mensaje = 'es el "mejor" local';

console.log(`${local} ${mensaje}`);