/**
 * Ejercicio 19
Crear un documento con el nombre ej19.js
Declarar una variable primerTexto con el valor: este texto tiene "comillas dobles"
Declarar una variable segundoTexto con el valor: este texto tiene 'comillas simples'
Mostrar en consola el valor de la variable primerTexto
Mostrar en consola el valor de la variable segundoTexto
*/

let primerTexto = 'este texto tiene "comillas dobles"',
    segundoTexto = "este texto tiene 'comillas simples'";

console.log(primerTexto);
console.log("***********");
console.log(segundoTexto);
