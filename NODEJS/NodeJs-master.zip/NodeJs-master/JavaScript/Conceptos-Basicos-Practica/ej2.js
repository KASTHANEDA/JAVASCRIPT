/**
 * Ejercicio 2
Crear un documento con el nombre ej2.js
Declarar las siguientes variables de forma individual:
nombre
apellido
edad
fecha de nacimiento
direccion
Asignar un valor a cada variable con tus datos personales:
Tu nombre
Tu apellido
Tu edad
Tu fecha de nacimiento
Tu direccion
 */

//Declaracion de variables;
var nombre;
var apellido;
var edad;
var fechaNac;

//Asigacion a la variable
nombre = 'Ezequiel';
apellido = 'Romero';
edad = 25;
fechaNac = '25/02/1994';

