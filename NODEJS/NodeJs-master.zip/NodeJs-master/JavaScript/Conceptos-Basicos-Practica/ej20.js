/**
 * Ejercicio 20
Crear un documento con el nombre ej20.js
Declarar la variable dia con el siguiente valor: el número del día de hoy

Declarar la variable mes con el siguiente valor: 
el número del mes de hoy (ejemplo: 1 para Enero,2 para Febrero)

Declarar la variable anio con el siguiente valor: año actual con 4 números 
(ejemplo: 2010).

Mostrar en consola el siguiente mensaje: dia/mes/anio
 */

let dia = 19,
    mes = 11,
    anio = 2019;

console.log(`${dia}/${mes}/${anio}`);