/**
 * Ejercicio 21
Crear un documento con el nombre ej21.js
Declarar una variable numérica edad con el siguiente valor: tu edad

Declarar una variable numérica telefono con el siguiente valor: 
el número de tu telefono

Declarar una variable string calle con el siguiente valor: 
el nombre de la calle donde vivis

Declarar una variable numérica altura con el siguiente valor: 
altura de la calle donde vivis

Mostrar en consola los siguientes mensajes:
Tengo edad años

Mi teléfono es telefono 
Vivo en calle al altura
Utilizar interpolación de textos
\
 */

let edad = 25,
    telefono = 0303456,
    calle = 'Calle falsa 1234',
    altura = 123;

console.log(`Mi teléfono es ${telefono}\nVivo en ${calle} ${altura}\n `)