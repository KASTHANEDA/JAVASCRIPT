/**
Ejercicio 22
Crear un documento con el nombre ej22.js
Declarar la variable salir y establecer el siguiente valor: true
Declarar la variable casado y establecer el siguiente valor: false
Declarar la variable usuarioRegistrado y establecer el siguiente valor: false
Declarar la variable meGustaJs y establecer el siguiente valor: true
Mostrar los valores de cada variable de la siguiente forma: 
console.log(nombreDeLaVariable, valor)
*/

let salir=true,
    casado=false,
    usuarioRegistrado=false,
    meGustaJs=true;


console.log('salir, '+ salir);
console.log('casado, '+ casado);
console.log('usuarioRegistrado, '+ usuarioRegistrado);
console.log('meGustaJs, '+ meGustaJs);

