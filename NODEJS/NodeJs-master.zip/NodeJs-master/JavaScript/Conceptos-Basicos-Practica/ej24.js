/**
 * Ejercicio 24
Crear un documento con el nombre ej24.js
Declarar la variable nombre y asignar el siguiente valor: null
Mostrar el valor de la variable de la siguiente forma: 
console.log(nombreDeLaVariable, valor)
*/

let nombre = null;
console.log('nombre, '+nombre);