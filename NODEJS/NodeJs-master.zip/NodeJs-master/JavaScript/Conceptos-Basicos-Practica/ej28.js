/**
 * Ejercicio 28
Crear un documento con el nombre ej28.js
Declarar la variable numero y asignar el valor 9
Mostrar en consola la tabla del 9 de 1 a 10 usando la variable numero
*/

let numero = 9;

console.log(`9 x 0 = ${numero*0}
9 x 1 = ${numero*1}
9 x 2 = ${numero*2}
9 x 3 = ${numero*3}
9 x 4 = ${numero*4}
9 x 5 = ${numero*5}
9 x 6 = ${numero*6}
9 x 7 = ${numero*7}
9 x 8 = ${numero*8}
9 x 9 = ${numero*9}
9 x 10 = ${numero*10}`)