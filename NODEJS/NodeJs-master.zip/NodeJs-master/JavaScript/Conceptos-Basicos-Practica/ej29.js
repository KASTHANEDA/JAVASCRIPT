/**
 * Ejercicio 29
Crear un documento con el nombre ej29.js
Calcular y mostrar en consola el perímetro de un cuadrado
(el perímetro es simplemente cuatro veces la longitud del lado)
La longitud del lado es de 10
*/

let perímetro, lado = 10;

perímetro = lado * lado;

console.log(`El perímetro es ${perímetro}`);