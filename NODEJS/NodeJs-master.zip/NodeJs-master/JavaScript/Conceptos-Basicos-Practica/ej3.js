/**
 * Ejercicio 3
Crear un documento con el nombre ej3.js
Declarar las siguientes variables en una misma línea:
nombre
apellido
edad
fecha de nacimiento
direccion
Asignar un valor a cada variable con tus datos personales:
Tu nombre
Tu apellido
Tu edad
Tu fecha de nacimiento
Tu direccion
 */

var nombre='Ezequiel', apellido='Romero', fechaNac='25/02/1994',
    direccion='calle false 1234';

