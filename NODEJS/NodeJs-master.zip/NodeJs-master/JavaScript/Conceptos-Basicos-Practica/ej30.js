/**
 * Ejercicio 30
Crear un documento con el nombre ej30.js
Calcular y mostrar en consola el área de un cuadrado (lado al cuadrado)
La longitud del lado es de 5
 */


let area, lado=5;

area = lado**2;

console.log(`El area del cuadrado es ${area}`);