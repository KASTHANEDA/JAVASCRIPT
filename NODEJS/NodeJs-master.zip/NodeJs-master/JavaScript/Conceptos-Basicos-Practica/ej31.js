/**
 * Ejercicio 31
Crear un documento con el nombre ej31.js
Calcular y mostrar en consola el perímetro de un triangulo (sumar los lados)
El lado 1 es de 10
El lado 2 es de 20
El lado 3 es de 5
*/

let perímetro, lado1=10, lado2=20, lado3=5;

perímetro = lado1 + lado2 + lado3;

console.log(`El perímetro del triangulo es ${perímetro}`);