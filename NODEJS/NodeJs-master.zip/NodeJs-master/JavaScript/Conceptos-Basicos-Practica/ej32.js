/**
 * Ejercicio 32
Crear un documento con el nombre ej32.js
Declarar la variable altura y asignar el valor 10
Declarar la variable base y asignar el valor 4
Mostrar en consola el cálculo del perímetro (suma de los lados) y el área (base por altura).
 */


let altura=10, base=4, perímetro, area;

//Area = base * altura de un cuadrado
//A = base * altura
area = base * altura;

//Perimetro p= 2*(base * area)
//p = 2*area + 2 * base

perímetro = (2 * area) + (2 * base);  





