/**
 * Ejercicio 39
Crear un documento con el nombre ej39.js
Declarar una variable nombre con tu nombre como valor
Declarar una variable apellido con tu apellido como valor

Mostrar en consola el siguientes mensajes:
Mi nombre es nombre y tiene nombre.length letras
Mi nombre es apellido y tiene apellido.length letras
Utilizar console.log() para cada mensaje
Utilizar interpolación de textos remplazando los valores de las variables nombre
y apellido y la cantidad de letras que tiene cada uno
Se puede utilizar variables auxiliares para la cantidad de letras que tienen los
valores de las variables nombre y apellido
 */

let nombre = 'Ezequiel', apellido = 'Romero';

console.log(`Mi nombre es ${nombre} y tiene ${nombre.length} letras`);
console.log(`Mi apellido es ${apellido} y tiene ${apellido.length} letras`);