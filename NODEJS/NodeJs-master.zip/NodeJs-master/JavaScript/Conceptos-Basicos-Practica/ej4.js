/**
* Ejercicio 4
Crear un documento con el nombre ej4.js
Declarar las siguientes variables de forma individual y asignarle a 
cada una un valor para describirte:

- nombre
- apellido
- edad
- fecha de nacimiento
- direccion
*/

var nombre = 'Ezequiel';
var apellido = 'Romero';
var fechaNac = '25/02/1994';
var direccion = 'Calle false 1234';