/**
 * Ejercicio 40
Crear un documento con el nombre ej40.js
Declarar la variable texto con el siguiente valor: Usando el método
Declarar la variable metodo con el siguiente valor: concat
Mostrar en consola el siguiente texto utilizando el método de string concat: Usando el método concat
 */

let texto = 'Usando el metodo ', metodo = 'concat';

// Concatenamos los strings usando el método concat
let mensaje = texto.concat(metodo);

console.log(mensaje);