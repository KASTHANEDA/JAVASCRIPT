/**
 * Ejercicio 41
Crear un documento con el nombre ej41.js
Declarar la variable texto y asignar el siguiente valor: HOLA MUNDO
Mostrar en consola el contenido de la variable texto en minúscula
 */

 let texto = 'HOLA MUNDO';
 /* El metodo toLowerCase() convierte mayusculas a minusculas */
 console.log(texto.toLowerCase());