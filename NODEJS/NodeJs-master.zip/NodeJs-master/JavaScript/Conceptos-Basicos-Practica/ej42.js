/**
 * Ejercicio 42
Crear un documento con el nombre ej42.js
Declarar la variable texto y asignar el siguiente valor: hola mundo
Mostrar en consola el contenido de la variable texto en mayúscula
 */

const texto = 'hola mundo';
//El metodo toUpperCase() convierte de minusculas a mayusculas
console.log(texto.toUpperCase());