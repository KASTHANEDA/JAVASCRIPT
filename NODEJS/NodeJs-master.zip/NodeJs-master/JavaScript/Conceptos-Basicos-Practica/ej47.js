/**
 * Ejercicio 47
Crear un documento con el nombre ej47.js

Declarar la variable alumnos y asignar el siguiente texto: 
Matías, Germán, Nicolás, Silvia, Estefi, Patricia, Ramóm
Asignar a la variable alumnos el resultado de ejecutar el método split sobre la variable alumnos
Mostrar por consola el contenido de la variable alumnos
 */

let alumnos = 'Matias, German, Nicolas, Silvia, Estefi, Patricia, Ramón';

console.log(alumnos.split());