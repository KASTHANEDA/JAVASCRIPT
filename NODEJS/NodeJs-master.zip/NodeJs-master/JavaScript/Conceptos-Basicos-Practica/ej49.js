/**
 * Ejercicio 49
Crear un documento con el nombre ej49.js
Declarar 2 variables numero1 y numero2
Asignar el valor 10 a la variable numero1
Asignar el valor 5 a la variable numero2
Si la variable numero1 es más grande que la variable numero2 entonces mostrar el
siguiente mensaje en consola: La variable numero1 es más grande que la variable numero2
Probar cambiar el valor de la variable numero2 para que sea más grande que numero1 
y volver a ejecutar el programar
 */

let numero1=10, numero2=55;

if (numero1 > numero2){
    console.log('La variable numero1 es más grande que la variable numero2');
}
else{
    console.log('La variable numero2 es más grande que la variable numero1');
}