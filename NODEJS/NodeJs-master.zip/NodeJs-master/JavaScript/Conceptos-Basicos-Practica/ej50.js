/**
 * Ejercicio 50
Crear un documento con el nombre ej50.js
Declarar la variable numero y asignar el valor 10
Si la variable numero es par Entonces mostrar en consola el mensaje: El número es par
Probar cambiar el valor de la variable numero por un número impar y volver a ejecutar
 */

let numero = 10;

if (numero %2==0){
    console.log('El número es par');
}
else{
    console.log('El número es impar');
}