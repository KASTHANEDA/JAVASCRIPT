/**
 * Ejercicio 51
Crear un documento con el nombre ej51.js
Declarar la variable usuario y asignar el valor 'pepe2017'
Declarar la variable password y asignar el valor '12345'
Si el nombre del usuario es igual a 'pepe2017' 
Y el password es igual a '12345' entonces mostrar en consola el 
siguiente mensaje: El usuario está autenticado y puede ver el contenido del sitio
 */

let usuario = 'pepe2017', password = '12345';

if(usuario == 'pepe2017'){
    console.log('El usuario está autenticado y puede ver el contenido del sitio');
}