/**
 * Ejercicio 52
Crear un documento con el nombre ej52.js
Copiar el código del ej49.md
Modificar el código para que cumpla con el nuevo requisito
Si la variable numero1 es más grande que la variable numero2 entonces
Mostrar el siguiente mensaje en consola: La variable numero1 es más grande que la variable numero2
SI NO :
Mostrar el siguiente mensaje: La variable numero1 no es más grande que la variable numero2
 */

let numero1=10, numero2=55;

if (numero1 > numero2){
    console.log('La variable numero1 es más grande que la variable numero2');
}
else{
    console.log('La variable numero1 no es más grande que la variable numero2');
}