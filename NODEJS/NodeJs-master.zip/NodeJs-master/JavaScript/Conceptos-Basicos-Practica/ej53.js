/***
 * Ejercicio 53
Crear un documento con el nombre ej53.js
Copiar el código del ej50.md
Modificar el código para que cumpla con el nuevo requisito
Si la variable numero es par Entonces
Mostrar en consola el mensaje: El número es par
SI NO :
Mostrar en consola el mensaje: El número no es par
 */

let numero = 10;

if (numero %2==0){
    console.log('El número es par');
}
else{
    console.log('El número no es impar');
}