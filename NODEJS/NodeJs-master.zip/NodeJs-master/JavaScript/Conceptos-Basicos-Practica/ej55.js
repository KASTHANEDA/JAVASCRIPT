/**
 * Ejercicio 55
Crear un documento con el nombre ej55.js
Copiar el código del ej52.md
Refactorizar el código y utilizar operador ternario en lugar de if/else
 */
/*
let numero1=10, numero2=55;

if (numero1 > numero2){
    console.log('La variable numero1 es más grande que la variable numero2');
}
else{
    console.log('La variable numero1 no es más grande que la variable numero2');
}
*/
let numero1=10, numero2=55;
//Utilizando condicionales TERNARIOS
(numero1 > numero2) ? console.log('La variable numero1 es más grande que la variable numero2') : console.log('La variable numero1 no es más grande que la variable numero2');