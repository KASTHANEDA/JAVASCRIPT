/**
 * Ejercicio 56
Crear un documento con el nombre ej56.js
Copiar el código del ej53.md
Refactorizar el código y utilizar operador ternario en lugar de if/else
 */
let numero = 10;
/*
if (numero %2==0){
    console.log('El número es par');
}
else{
    console.log('El número no es impar');
}
*/
//Condicionales TERNARIO

(numero % 2 == 0) ? console.log('El número es par') : console.log('El número no es impar');

