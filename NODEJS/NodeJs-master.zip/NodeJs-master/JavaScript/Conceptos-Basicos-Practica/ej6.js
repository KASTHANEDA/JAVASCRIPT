/**
 * Ejercicio 6
Crear un documento con el nombre ej6.js
Declarar las siguientes variables de forma individual y asignarle a 
cada una un valor para describirte:

- nombre
- apellido
- edad
- fecha de nacimiento
- direccion

Mostrar en consola el valor y nombre de cada una de las variables utilizando
console.log()
 */

//Lo resolvi en el ejercicio anterior