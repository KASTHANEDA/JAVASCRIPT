/**
 * Ejercicio 8
Crear un documento con el nombre ej8.js
Copiar el contenido del ej7.js y pegarlo en el nuevo archivo
Cambiar let por const
 */

const nombre = 'Ezequiel', 
      apellido = 'Romero', 
      edad = 25, fechaNac = '25/02/1994',
      direccion = 'Calle falsa 1234';

console.log(`Su nombre: ${nombre}, ${apellido} su edad ${edad} años, fecha de nacimiento ${fechaNac} y vive en ${direccion}`);
