/**
 * Ejercicio 9
Crear un documento con el nombre ej9.js
Crear una variable nombre como constante y asignale tu nombre
En la línea siguiente asignale a la variable nombre otro valor
Ejecutar el programa y ver que pasa
 */

//Al ser una variable declarada como constante no se le puede cambiar 
//el valor asignado por eso nos tira un error
const nombre = 'Ezequiel';
nombre = 'Pepe';

console.log(nombre);