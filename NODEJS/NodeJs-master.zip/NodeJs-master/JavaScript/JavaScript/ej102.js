/**
 * Ejercicio 102
Crear un documento con el nombre ej102.js
Declarar una variable mostrarNombre y asignar una función
La función mostrarNombre tiene que mostrar tu nombre en consola 
con el siguiente formato:
  ===========
  = Nicolás =
  ===========
Ejecutar esta función 2 veces
 */

const mostrarNombre = (nombre) =>{
  console.log(`============\n
= ${nombre} =\n
============`)

};

mostrarNombre('Ezequiel');