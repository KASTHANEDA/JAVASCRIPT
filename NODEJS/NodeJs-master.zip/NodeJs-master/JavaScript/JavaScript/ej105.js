/**
 * Ejercicio 105
Crear un documento con el nombre ej105.js
Crear una función que se llame significadoDeLaVida y retorna el número 42
Mostrar en consola el siguiente mensaje: 
El significado de la vida es ${significadoDeLaVida}
 */

const significadoDeLaVida = () =>{
    return 42;
}

console.log(`El significado de la vida es ${significadoDeLaVida()}`)