/**
 * Ejercicio 117
Crear un documento con el nombre ej117.js
Declarar un arreglo de alumnos con el nombre de 5 compañeros del curso
Mostrar en consola el nombre del primero, tercer y quinto compañero
 */

let alumnos = ['ezequiel', 'jose', 'gabriela', 'luis', 'angela'];

console.log(`El primer alumno que se encuentra en el arreglo es ${alumnos[0]},
el tercer alumno es ${alumnos[2]} y el quinto alumna es ${alumnos[4]}`)