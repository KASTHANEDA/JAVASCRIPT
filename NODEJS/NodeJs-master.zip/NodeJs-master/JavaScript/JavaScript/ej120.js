/**
 * Ejercicio 120
Crear un documento con el nombre ej120.js
Declarar un array vacio con el nombre alumnos
Asignar el nombre de un alumno en los ínidices: 0, 1, 2, 3, 4 y 5
Mostrar en consola cada uno de los elementos utilizando los índices dados
Ejemplo de formato de salida: índice 0: Marta
 */

let alumnos = ['Marta','Jose','Damian','Gabriela','Ezequiel', 'Noemi'];

console.log(`${alumnos[0]}\n${alumnos[1]}\n${alumnos[2]}\n${alumnos[3]}\n${alumnos[4]}\n${alumnos[5]}`);