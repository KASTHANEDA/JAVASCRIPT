/**
 * Ejercicio 123
Crear un documento con el nombre ej123.js
Declarar una lista de alumnos con varios de los nombres de tus compañeros
Mostrar en consola el nombre del 2do y 6to alumno en mayúscula
Mostrar en consola la cantidad de alumnos
 */

let alumnos = ['Ezequiel','Gabriela','Josema','Luis','Marta',
'Noemi','Damian','Ivanna','Roberto','Angela','Silvia','Emilia','Nestor'];

console.log(alumnos[1].toUpperCase ``)
console.log(alumnos[5].toUpperCase ``)