/**
 * Ejercicio 125
Crear un documento con el nombre ej125.js
Crear una lista de gustos de helados
Asignar 10 gustos que te gusten
No se puede utilizar índices numéricos
Los elementos tienen que estar en el orden que fueron ingresados, 
primero el primero, segundo el segundo y así sigue
Mostrar en consola la lista de gustos de helados
 */

let helados = ['crema del cielo', 'granizado', 'chocolate', 'dulce de leche', 
'frutillas','banana split', 'almendrado','amarena','crema con frutillas',
'chocolate nevado'];

for(let i=0; i < helados.length; i++){
    console.log(helados[i]);
}
