/**
 * Ejercicio 64
Crear un documento con el nombre ej64.js
Declarar una variable nombre y asignar el valor null
Si nombre Entonces
Mostrar un mensaje en la consola: El nombre del usuario es ${nombre}
SINO
Mostrar un mensaje de error en la consola: Por favor ingrese un nombre
Cambiar el valor de la variable nombre con tu nombre y volver a ejecutar
el programa a ver que pasa
 */

let nombre;
nombre = prompt('Ingrese un nombre: ');

if (nombre != 'null'){
    document.write(`El nombre del usuario es ${nombre}`);
}else{
    document.write('Por favor ingrese un nombre');
}