/**
 * Ejercicio 66
Crear un documento con el nombre ej66.js
Mostrar en consola los números del 0 al 10 utilizando la estructura while
 */

i=0;
while(i <= 10){
    console.log(i);
    i++;
    
}