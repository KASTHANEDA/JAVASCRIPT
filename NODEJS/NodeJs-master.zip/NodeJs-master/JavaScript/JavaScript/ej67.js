/**
 * Ejercicio 67
Crear un documento con el nombre ej67.js
Mostrar en consola los números del 100 al 0 utilizando la estructura while
 */

let i=100;

while(i >= 0){
    console.log(i);
    i--;
    
}