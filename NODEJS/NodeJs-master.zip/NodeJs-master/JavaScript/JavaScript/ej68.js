/**
 * Ejercicio 68
Crear un documento con el nombre ej68.js
Mostrar en consola los números pares del 0 al 1000 utilizando la estructura while
 */

let i = 0;

while(i <= 1000){
    console.log(i);
    i++;
}