/**
 * Ejercicio 71
Crear un documento con el nombre ej71.js
Mostrar en consola la tabla de multiplicar del 9 (de 1 a 10) utilizando 
la estructura while
 */

let i=0;

while(i <= 10){

    console.log(i*(9));
    i++;
}