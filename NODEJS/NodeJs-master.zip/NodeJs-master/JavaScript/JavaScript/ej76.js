/**
 * Ejercicio 76
Crear un documento con el nombre ej76.js
Copiar y pegar el código del ejercicio ej66.js
Refactorizar el código utilizando la estructura do/while en lugar de while
 */

i=0;
do{
    console.log(i);
    i++;
}while(i <= 10)