/**
 * Ejercicio 77
Crear un documento con el nombre ej77.js
Copiar y pegar el código del ejercicio ej67.js
Refactorizar el código utilizando la estructura do/while en lugar de while
 */

let i=100;

do{
    console.log(i);
    i--;
    
}
while(i >= 0)