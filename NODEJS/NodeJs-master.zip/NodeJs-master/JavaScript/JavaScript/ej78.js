/**
 * Ejercicio 78
Crear un documento con el nombre ej78.js
Copiar y pegar el código del ejercicio ej68.js
Refactorizar el código utilizando la estructura do/while en lugar de while
 */


let i = 0;

do{
    console.log(i);
    i++;
}
while(i <= 1000)