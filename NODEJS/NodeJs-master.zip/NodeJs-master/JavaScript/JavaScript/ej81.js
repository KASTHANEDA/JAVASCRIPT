/**
 * Ejercicio 81
Crear un documento con el nombre ej81.js
Copiar y pegar el código del ejercicio ej71.js
Refactorizar el código utilizando la estructura do/while en lugar de while
 */


let i=0;

do{
    console.log(i*(9));
    i++;
}
while(i <= 10)