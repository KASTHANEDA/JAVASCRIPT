/**
 * 
 * Ejercicio 86
Crear un documento con el nombre ej86.js
Copiar y pegar el código del ejercicio ej76.js
Refactorizar el código utilizando la estructura for en lugar de do/while
 */


for(let i=0; i <= 10; i++){
    console.log(i);
}
