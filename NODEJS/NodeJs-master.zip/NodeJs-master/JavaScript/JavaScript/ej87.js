/**
 * Ejercicio 87
Crear un documento con el nombre ej87.js
Copiar y pegar el código del ejercicio ej77.js
Refactorizar el código utilizando la estructura for en lugar de do/while
 */



for(let i = 100; i >=0 ; i--){
    console.log(i);
}
