/**
 * 
 * Ejercicio 88
Crear un documento con el nombre ej88.js
Copiar y pegar el código del ejercicio ej78.js
Refactorizar el código utilizando la estructura for en lugar de do/while
 */

let i = 0;
for(i; i <= 1000; i++){
    console.log(i);
}