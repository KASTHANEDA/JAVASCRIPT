/**
 * Ejercicio 91
Crear un documento con el nombre ej91.js
Copiar y pegar el código del ejercicio ej81.js
Refactorizar el código utilizando la estructura for en lugar de do/while
 */

let i=0;

for(i; i <= 10; i++){
    console.log(i*(9));
}

