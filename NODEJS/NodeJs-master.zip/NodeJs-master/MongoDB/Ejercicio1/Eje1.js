/* Ejercicio 1
Levantar el servidor de MongoDB. Conectarse al cliente de MongoDB. Crear una
base de datos con el nombre catalogo. Crear la colección productos
Crear los siguientes documentos de a uno:

{"name": "MacBook Pro"}
{"name": "MacBook Air"}
{"name": "MacBook"})

Listar las bases de datos disponibles. Listar las colecciones disponibles 
para la base de datos catalogo. Desconectar el cliente de MongoDB
Volver a levantar el cliente de MongoDB pero en esta oportunidad queremos que 
se conecte directamente a la base de catalogo sin pasar por la base de test*/