/**
 * Ejercicio 1
Crear una carpeta con el nombre ej1
Inicializar un proyecto de Node.js utilizando NPM dentro de la carpeta ej1
El nombre del proyecto tiene que ser Ejercicio 1. Crear un archivo index.js
Configurar el proyecto para que al correr npm start corra el código del archivo 
index.js. Como resultado de correr el script tiene que mostrar en consola el 
siguiente mensaje:
Corriendo código desde mi primer script!!!
 */

