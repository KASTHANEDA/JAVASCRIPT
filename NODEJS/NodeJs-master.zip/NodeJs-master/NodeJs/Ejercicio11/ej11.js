/**
Ejercicio 11
Crear un archivo con el nombre ej11.js
Levantar un servidor de Express
Crear un archivo html con el nombre index.html
Crear un archivo html con el nombre productos.html
Al llamar a localhost:3000 se debe mostrar el archivo index.html
Al llamar a localhost:3000/products se debe mostrar el archivo productos.html
index.html
Crear un archivo HTML bien formado
Agregar un título h1 con el texto 'Home'
Agregar un título h2 autogenerado
Agregar 3 párrafos autogenerados
Agregar un link para ir a la sección de productos
productos.html
Crear un archivo HTML bien formado
Agregar un título h1 con el texto 'Productos'
Crear una tabla con 10 productos que te gustaría comprarte
Mostrar en la tabla los siguientes datos:
Descripción del producto o nombre
Precio
Lugar donde lo venden
*/