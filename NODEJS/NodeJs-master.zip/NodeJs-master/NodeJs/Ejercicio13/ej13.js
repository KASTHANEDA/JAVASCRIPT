/**
 * Ejercicio 13
Crear un archivo con el nombre ej13.js
Levantar un servidor de Express
Crear un módulo para manejar las rutas de nuestra home (get y post)
Crear un módulo para manejar las rutas de nuestros productos (get, post, delete, put)
Cada ruta sólo tiene que enviar un mensaje diciendo que página es y 
que método utiliza
res.send('Pagina: home, método: post')
Montar las rutas de home en '/'
Montar las rutas de prodcutos en '/productos'
 */