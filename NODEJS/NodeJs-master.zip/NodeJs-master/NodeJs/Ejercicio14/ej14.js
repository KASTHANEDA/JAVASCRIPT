/**
 * Ejercicio 14
Crear un archivo con el nombre ej14.js
Levantar un servidor de Express
Crear la siguiente ruta, url: '/', metodo: get
Esta ruta tiene que retornar un mensaje que dice: 'Este request/response está OK',
usar el método send para la respuesta
Establecer el status en 200
Crear la siguiente ruta, url: '/productos', metodo: get
Esta ruta tiene que retornar un mensaje que dice: 'Ha ocurrido un error de servidor',
usar el método send para la respuesta
Establecer el status en 500
Crear la siguiente ruta, url: '/contacto', metodo: get
Esta ruta tiene que retornar un mensaje que dice: '404 No encontrado', usar el método
send para la respuesta
Establecer el status en 404
 */