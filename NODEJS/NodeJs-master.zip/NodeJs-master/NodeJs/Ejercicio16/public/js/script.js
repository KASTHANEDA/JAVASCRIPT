console.log('Estamos sirviendo un archivo ECMAScript desde el servidor!!!!!');
