/**
 * 
Ejercicio 17: Crear una carpeta con el nombre sitio-node
Replicar el sitio usando handlebars y express explicado en la sección
Armar un sitio
 */