/**
 * Ejercicio 2
Crear una carpeta con el nombre ej2
Inicializar un proyecto de Node.js utilizando NPM dentro de la carpeta ej2
El nombre del proyecto tiene que ser Ejercicio 2
Crear un archivo index.js
Instalar el módulo Express como dependencia de nuestro proyecto
Configurar el proyecto para que al correr npm start
corra el código del
archivo index.js. Mostrar en consola el objeto express
 */