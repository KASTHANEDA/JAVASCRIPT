const express = require('express');
//Muestro en consola al objeto express
console.log(express);