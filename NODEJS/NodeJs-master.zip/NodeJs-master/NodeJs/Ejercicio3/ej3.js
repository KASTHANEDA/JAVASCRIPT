/**
 * Ejercicio 3
Crear una carpeta con el nombre ej3
Inicializar un proyecto de Node.js utilizando NPM dentro de la carpeta ej3
El nombre del proyecto tiene que ser Ejercicio 3
Crear un archivo index.js
Leer la documentación del módulo para aprender a usarlo
Instalar el módulo logplease como solo dependencia de desarrollo de nuestro proyecto
Configurar el proyecto para que al correr npm start corra el código del archivo 
index.js. Mostrar en consola:

Hola Mundo de Node (usando el método debug)
Información de último momento, Node.js es lo más!! (usando el método info)
Tirando warnings como campeones (usando el método warn)
Algo no está bien!!! (usando el método error)
 */