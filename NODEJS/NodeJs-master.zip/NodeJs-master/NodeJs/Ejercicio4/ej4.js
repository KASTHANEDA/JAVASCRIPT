/**
 * Ejercicio 4
Crear una carpeta con el nombre ej4
Inicializar un proyecto de Node.js utilizando NPM dentro de la carpeta ej4
El nombre del proyecto tiene que ser Ejercicio 4
Crear un archivo index.js
Leer la documentación del módulo para aprender a usarlo
Instalar el módulo one-liner-joke
Configurar el proyecto para que al correr npm start corra el código del archivo 
index.js. Mostrar en consola un chiste random. Mostrar en consola las categoría
a las que pertenece. Nota de color:
 
el método getRandomJoke retorna un objeto que tiene una propiedad body con el chiste
y la propiedad tags con las categorías
 */