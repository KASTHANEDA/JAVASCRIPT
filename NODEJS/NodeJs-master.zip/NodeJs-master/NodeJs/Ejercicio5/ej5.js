/**
 * Ejercicio 5
Crear una carpeta con el nombre ej5
Inicializar un proyecto de Node.js utilizando NPM dentro de la carpeta ej5
El nombre del proyecto tiene que ser Ejercicio 5
Crear un archivo index.js
Crear un archivo numeros.js

Declarar una función con el nombre esPar, esta función acepta un número como 
parámetro. Retorna un valor boolean true en caso de que el valor sea par y false
en caso de que no lo sea. Exportar la función index.js. Instalar el 
módulo logplease como solo dependencia de desarrollo de nuestro proyecto. 
Importar el módulo logplease. Importar el módulo numeros Llamar a la función
es par con los siguientes valores:

2, 3, 101, 201, 202, 100

Si el número es par mostrar en consola el siguiente mensaje utilizando los 
métodos indicados del módulo logplease:
El número es par (utilizar el método info)
Sino
El número no es par (utilizar el método error)
 */