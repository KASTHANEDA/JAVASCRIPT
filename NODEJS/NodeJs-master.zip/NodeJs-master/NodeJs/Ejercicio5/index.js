const Logger = require('logplease');

let numero = require('./numeros.js');

console.log("El numero 2 es par : " + numero(2));
console.log("El numero 3 es par : " + numero(3));
console.log("El numero 101 es par : " + numero(101));
console.log("El numero 201 es par : " +numero(201));
console.log("El numero 202 es par : " +numero(202));
console.log("El numero 100 es par : " +numero(100));

