module.exports = function esPar(numero) {
    if(numero % 2 == 0){
        return true;
    }else{
        return false;
    }
}

