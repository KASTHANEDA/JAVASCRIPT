/**
 * Ejercicio 6
Crear un archivo con el nombre ej6.js
Crear una arrow function con el nombre saludar
Esta función acepta 3 parámetros. El primer parámetro es el nombre de la
persona que queremos saludar. El segundo parámetro es el apellido de la persona
que queremos saludar. Esta función muestra en pantalla el siguiente mensaje:

`Hola ${nombre}` ${apellido}`

El tercer parámetro es un callback que se va a ejecutar luego de saludar al usuario
Esta función tiene que mostrar en pantalla el siguiente texto:

'Luego de saludar se ejecuta el callback'

Al correr el script deberíamos ver en pantalla el saludo
 */
