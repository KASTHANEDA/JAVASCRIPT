/**
 * Ejercicio 7
Crear una carpeta con el nombre ej7
Crear un archivo con el nombre index.js
Crear un archivo con el nombre saludador.js
Requerir el módulo saludador
Utilizar la función saludar exportada
Pasarle los 3 parámetros desde este archivo (nombre, apellido y callback)
saludador.js
Copiar y pegar la función saludar del ejercicio anterior (ej6) en el archivo 
saludador.js
Exportar la función saludar

Correr el proyecto con npm start (index.js)
 */