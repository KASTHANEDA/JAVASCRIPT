let mostrar = require('./saludador.js');

mostrar('Ezequiel', 'Romero');