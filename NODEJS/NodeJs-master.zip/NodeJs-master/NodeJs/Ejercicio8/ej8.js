/**
 * Ejercicio 8
Crear un archivo con el nombre ej8.js
Levantar un servidor HTTP en el puero 3001, ejecutar un request a localhost:3001.
El servidor tiene que responder con el siguiente texto:
 
'Bienvenidos a Node.js Server Side'. Al levantar el servidor tiene que mostrar
un mensaje que diga: `Servidor corriendo en el puerto ${puerto}`. En caso de haber un
error al levantar el servidor tiene que mostrar el siguiente mensaje:

`No se pudo levantar el servidor en el puerto ${puerto}`
(AYUDIN) podes copiar el código de la guía y modificarlo
 */