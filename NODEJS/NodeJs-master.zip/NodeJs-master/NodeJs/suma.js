let SumarDosNumeros = function(){
    return 2+2;
}

exports.SumarDosNumeros = SumarDosNumeros;

exports.suma = SumarDosNumeros;